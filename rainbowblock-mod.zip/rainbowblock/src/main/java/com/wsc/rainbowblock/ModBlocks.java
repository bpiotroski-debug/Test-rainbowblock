package com.wsc.rainbowblock;

import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(RainbowBlockMod.MODID);

    public static final DeferredBlock<Block> RAINBOW_BLOCK = BLOCKS.registerSimpleBlock(
            "rainbow_block",
            BlockBehaviour.Properties.of()
                    .mapColor(net.minecraft.world.level.material.MapColor.COLOR_PINK)
                    .strength(2.0f)
                    .sound(SoundType.AMETHYST)
                    .lightLevel(state -> 15)
    );
}

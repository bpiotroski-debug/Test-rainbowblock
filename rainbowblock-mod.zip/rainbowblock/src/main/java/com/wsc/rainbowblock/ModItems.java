package com.wsc.rainbowblock;

import net.minecraft.world.item.BlockItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RainbowBlockMod.MODID);

    public static final DeferredHolder<net.minecraft.world.item.Item, BlockItem> RAINBOW_BLOCK_ITEM =
            ITEMS.registerSimpleBlockItem("rainbow_block", ModBlocks.RAINBOW_BLOCK);
}
